package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class second extends AppCompatActivity {
         Button button2, btn ,button4,button5,button7 ,button3;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this,alaram.class);
                startActivity(intent);
            }
        });


        btn =findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this,slide.class);
                startActivity(intent);
            }
        });
        button7 = findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this,medtrack.class);
                startActivity(intent);
            }
        });
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this,exercise.class);
                startActivity(intent);
            }
        });

          button4 = findViewById(R.id.button4);
          button4.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  gotoUrl("https://www.google.com/maps/search/hospital/@12.8850073,77.5013346,13z/data=!3m1!4b1");
              }
          });
        button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://m.docsapp.in/?gclid=Cj0KCQjw1tGUBhDXARIsAIJx01m4f6RKei2SOWfgq5WIXSgVpSKH0yxQaWaze37LZgsZrhVIjRT1DXwaAn3SEALw_wcB");
            }
        });






    }
     private void gotoUrl(String s){
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));


     }

}